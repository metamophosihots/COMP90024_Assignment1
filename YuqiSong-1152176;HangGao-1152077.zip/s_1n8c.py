#!/usr/bin/python
# -*- coding: UTF-8 -*-

import time
starttime=time.time()

from mpi4py import MPI
import sys
import json
import calculate as c
import io
import sys
import subprocess

comm=MPI.COMM_WORLD
size = comm.Get_size()
rank = comm.Get_rank()
name = MPI.Get_processor_name()

msg=""


#get filename, get number of lines in this file
import sys
import subprocess

if len(sys.argv)>1:
        fname=sys.argv[1]
        p = subprocess.Popen(['wc', '-l', fname], stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        r, err = p.communicate()
        if p.returncode != 0:
                raise IOError(err)
        linecount=int(r.strip().split()[0])


else:
        fname="bigTwitter.json"
        linecount=4233611



if rank == 0:
        ##master process
        i=0
        emotion_dictionary = c.readEmotionDictionary()
        zone_happiness_points = c.initializeZoneHappinessPoints()
        zone_twitter_counts = c.initializeZoneTwitterCount()
        with io.open(fname,"r",encoding="UTF-8") as lines:
                interval=int(linecount/size)
                r1=rank*interval
                if rank!=size-1:
                        r2=(rank+1)*interval
                else:
                        r2=linecount
                for line in lines:
                        if i==0 or i < r1 or i >= r2:
                        #skip first line
                        #and make sure working on its own part
                                i=i+1
                                continue
                        #deal with a few ending patterns and cast to dic
                        if (line[len(line)-3]+line[len(line)-2])=="]}":
                                tmp=line[0:len(line)-3]
                                if tmp =="":
                                        continue
                                l=json.loads(tmp)
                        elif (line[len(line)-3]+line[len(line)-2])=="},":
                                tmp=line[0:len(line)-2]
                                l=json.loads(tmp)
                        elif line[len(line)-2]=="}":
                                l=json.loads(line)
                        else:
                                print("unseen pattern of end line,skipped:")
                                print(line)
                                continue
                        i=i+1
                        zone_happiness_points,zone_twitter_counts=c.processSingleLine(l,zone_twitter_counts,zone_happiness_points)

        receivedScore=[zone_happiness_points]
        receivedCount=[zone_twitter_counts]
        for i in range(size-1):
                s,c=comm.recv(source=i+1,tag=77)
                receivedScore.append(s)
                receivedCount.append(c)
        ##sum up received data by area here
        sumedScore={}
        sumedScore=dict.fromkeys(receivedScore[0].keys(),0)
        for dic in receivedScore:
                for k,v in dic.items():
                        sumedScore[k]=sumedScore[k]+v
        sumedCount={}
        sumedCount=dict.fromkeys(receivedCount[0].keys(),0)
        for dic in receivedCount:
                for k,v in dic.items():
                        sumedCount[k]=sumedCount[k]+v
        endtime=time.time()
        dtime=endtime-starttime
        print ("----------------------------------------\nresult:\nScore:" + str(sumedScore))
        print ("\nCount:"+str(sumedCount))
        print ("time:"+str(dtime))

else:
        ##slave process
        emotion_dictionary = c.readEmotionDictionary()
        zone_happiness_points = c.initializeZoneHappinessPoints()
        zone_twitter_counts = c.initializeZoneTwitterCount()

        i=0
        with io.open(fname,"r",encoding="UTF-8") as lines:
                interval=int(linecount/size)
                r1=rank*interval
                if rank!=size-1:
                        r2=(rank+1)*interval
                else:
                        r2=linecount
                for line in lines:
                        if i==0 or i not in range(r1,r2):
                                i=i+1
                                continue
                        if (line[len(line)-3]+line[len(line)-2])=="]}":
                                tmp=line[0:len(line)-3]
                                if tmp =="":
                                        continue
                                l=json.loads(tmp)
                        elif (line[len(line)-3]+line[len(line)-2])=="},":
                                tmp=line[0:len(line)-2]
                                l=json.loads(tmp)
                        elif line[len(line)-2]=="}":
                                l=json.loads(line)
                        else:
                                print("unseen pattern of end line,skipped:")
                                print(line)
                                continue
                        i=i+1
                        zone_happiness_points,zone_twitter_counts=c.processSingleLine(l,zone_twitter_counts,zone_happiness_points)
        comm.send((zone_happiness_points,zone_twitter_counts),dest=0,tag=77)



