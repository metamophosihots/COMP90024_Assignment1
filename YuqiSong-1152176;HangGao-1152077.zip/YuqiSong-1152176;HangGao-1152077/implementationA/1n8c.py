import time
starttime=time.time()

from mpi4py import MPI
import sys
import json
import calculate as c
import io


comm=MPI.COMM_WORLD
size = comm.Get_size()
rank = comm.Get_rank()
name = MPI.Get_processor_name()
#print("-- rank = "+str(rank))
msg=""

if rank == 0:
	##master process
	total_lines=0
	destination=1

	##TODO:read data from file as stream, then serialize each str to dict
	i=0
	file=[]#file: [dict1,dict2....]
	with io.open("bigTwitter.json","r",encoding="UTF-8") as lines:
		for line in lines:
			
			#print("【Master】reading line " + str(line) + "/"+str(len(file)))
			if i==0:
				i=i+1
				continue
			
			if (line[len(line)-3]+line[len(line)-2])=="]}":
				#print(line)
				tmp=line[0:len(line)-3]
				if tmp =="":
					#print(line)
					continue
				l=json.loads(tmp)
			elif (line[len(line)-3]+line[len(line)-2])=="},":
				tmp=line[0:len(line)-2]
				l=json.loads(tmp)
			elif line[len(line)-2]=="}":
				l=json.loads(line)
			else:
				print("unseen pattern of end line,skipped:")
				print(line)
				continue
			i=i+1
			comm.send(l,dest=destination,tag=1)
			#print("【Master】data sent to "+str(destination))
			destination=destination+1
			if destination==size:
				destination=1
			total_lines=total_lines+1
		#print("total lines:"+str(i))
		#print("【Master】end of sending process")
		for i in range(0,size):
			comm.send("end",dest=i,tag=1)
			
	
	#sending process is end. now waiting for all data sending back
	#print("【Master】sent ending signal")
	receivedScore=[]
	receivedCount=[]
	for i in range(size-1):
		s,c=comm.recv(source=i+1,tag=77)
		receivedScore.append(s)
		receivedCount.append(c)
	##TODO: sum up (received) by area here
	sumedScore={}
	sumedScore=dict.fromkeys(receivedScore[0].keys(),0)
	for dic in receivedScore:
		for k,v in dic.items():
			sumedScore[k]=sumedScore[k]+v
	sumedCount={}
	sumedCount=dict.fromkeys(receivedCount[0].keys(),0)
	for dic in receivedCount:
		for k,v in dic.items():
			sumedCount[k]=sumedCount[k]+v
	endtime=time.time()
	dtime=endtime-starttime
	print ("----------------------------------------\nresult:\nScore:" + str(sumedScore))
	print ("\nCount:"+str(sumedCount))
	print ("time:"+str(dtime))

else:
	##slave process
	##initialize
	emotion_dictionary = c.readEmotionDictionary()
	zone_happiness_points = c.initializeZoneHappinessPoints()
	zone_twitter_counts = c.initializeZoneTwitterCount() 	
	while msg!="end":
		line=comm.recv(source=0,tag=1)
		if line=="end":
			msg="end"
		else:
			zone_happiness_points,zone_twitter_counts=c.processSingleLine(line,zone_twitter_counts,zone_happiness_points)
			#print("【Worker"+str(rank)+"】 received data slice from Master:" + str(line))

	#print("【Worker"+str(rank)+"】 end of receiving data slices")	
	#print(zone_happiness_points)
	#print(zone_twitter_counts)
	#print("----")
	comm.send((zone_happiness_points,zone_twitter_counts),dest=0,tag=77)


