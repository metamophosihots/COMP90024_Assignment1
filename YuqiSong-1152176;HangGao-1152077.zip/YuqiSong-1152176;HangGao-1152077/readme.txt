-To run:
sbatch srun.slurm

To run different data rather than bigTwitter.json, add directory path after each srun command in slurm file.
e.g:
srun -N 1 -n 8 python3 s_1n8c.py tinyTwitter.json

-implementationA
The first implementation.
It does not shorten the total time cost but increased it. 
It's saved here as a support evidence for the report.