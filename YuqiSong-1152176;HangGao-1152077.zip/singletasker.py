import time
starttime=time.time()

from mpi4py import MPI
import sys
import json
import calculate as c
import io


comm=MPI.COMM_WORLD
size = comm.Get_size()
rank = comm.Get_rank()
name = MPI.Get_processor_name()
#print("-- rank = "+str(rank))
msg=""

if rank == 0:
        ## this is master process
        total_lines=0

        emotion_dictionary = c.readEmotionDictionary()
        zone_happiness_points = c.initializeZoneHappinessPoints()
        zone_twitter_counts = c.initializeZoneTwitterCount()

        ## read data from file line by line, then serialize each str to dict
        i=0
        with io.open("bigTwitter.json","r",encoding="UTF-8") as lines:
                for line in lines:
                        if i==0:
                                i=i+1
                                continue

                        if (line[len(line)-3]+line[len(line)-2])=="]}":
                                #print(line)
                                tmp=line[0:len(line)-3]
                                if tmp =="":
                                        #print(line)
                                        continue
                                l=json.loads(tmp)
                        elif (line[len(line)-3]+line[len(line)-2])=="},":
                                tmp=line[0:len(line)-2]
                                l=json.loads(tmp)
                        elif line[len(line)-2]=="}":
                                l=json.loads(line)
                        else:
                                print("unseen pattern of end line,skipped:")
                                print(line)
                                continue
                        i=i+1
                        
                        #comm.send(l,dest=destination,tag=1)
                        #We dont have a slave so we have to do it ourselves
			
                        zone_happiness_points,zone_twitter_counts=c.processSingleLine(l,zone_twitter_counts,zone_happiness_points)
                        total_lines=total_lines+1
                #print("total lines:"+str(i))
        sumedScore=zone_happiness_points
        sumedCount=zone_twitter_counts
        endtime=time.time()
        dtime=endtime-starttime
        print ("----------------------------------------\nresult:")
        print("Cell     #Total Tweets #Overal Sentiment Score")
        for k in sumedScore.keys():
                print("{}       {}           {}".format(k,sumedCount[k],sumedScore[k]))
        print ("time:"+str(dtime))
